<aside class="main-sidebar">
    <section class="sidebar">
    	<ul class="sidebar-menu">
        <li class="header">MAIN MENU
        </li>
       
        <li>
          <a href="{{ url('home') }}">
            <i class="glyphicon glyphicon-home"></i>
            <span>Dashboard</span></a>
        </li>

        <li>
          <a href="{{ url('blood')}}">
            <i class="glyphicon glyphicon-plus"></i>
            <span>Blood</span>
          </a>
      </li>
          <li>
          <a href="{{ url('category')}}">
            <i class="glyphicon glyphicon-file">
            </i> <span>Blood Type</span>
          </a>
      </li>
      <li>
          <a href="{{ url('users') }}">
            <i class="glyphicon glyphicon-user"></i> 
            <span>Users</span>
          </a>
        </li>
      </ul>
    </section>


        
   
     
   