<footer class="main-footer">
        <strong>Copyright &copy; 2017.</strong>
      </footer>
    </div>