<?php $__env->startSection('content'); ?>
	<div class="content-wrapper">
    	<section class="content-header">
        <h1>
          <i class="glyphicon glyphicon-user">
          Users
          </i>
        </h1>

        <ol class="breadcrumb">
          <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
          <li><a href="#">Users</a></li>
        </ol>
      </section>

      <section class="content">
        <div class="row">
          <div class="col-xs-12">
            <div class="box">
              <div class="box-header">
              <a class="btn btn-primary pull-right" href="users/create">Create Users</a>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table class="table table-bordered table-hover">
                <thead>
                <tr>
                  <th>No.</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                 <?php $no=0; foreach($users_list as $users): $no++ ?>
                    <tr>
                      <td class="center"><?php echo e($no); ?></td>
                      <td><?php echo e($users->name); ?></td>
                      <td class="left"><?php echo e($users->email); ?></td>
                      <td>
                          <a href="user/<?php echo e($users->id .'/edit'); ?>" class="btn btn-primary btn-sm"><i class="glyphicon glyphicon-edit"></i></a>
                          <a href="user/<?php echo e($users->id .'/destroy'); ?>" class="btn btn-primary btn-sm"><i class="glyphicon glyphicon-erase"></i></a>
                          
                      </td>
                    </tr>
                  <?php endforeach ?>
                </tbody>
              </table>
              <?php echo e($users_list); ?>

             </div>
           </div>
         </div>
       </div>
     </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>