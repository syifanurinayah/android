<?php $__env->startSection('content'); ?>
	<div class="content-wrapper">
    	<section class="content-header">
      <h1>
        <i class="glyphicon glyphicon-plus">
        Blood
        </i>
      </h1>
      
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Blood</a></li>
        <li class="active">Data Blood</li>
      </ol>
    </section>

    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Data Blood</h3>
              <a class="btn btn-primary pull-right" href="blood/create">Blood</a>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <?php if(!empty($blood_list)): ?>
              <table id="dataTables1" class="table table-bordered table-striped table-hover">
                <thead>
                <tr>
                  <th class="center">No.</th>
                  <th class="center">Nama</th>
                  <th class="center">Type Blood</th>
                  <th class="center">Alamat</th>
                  <th class="center">Keterangan</th>
                  <td colspan="2"></td>
                </tr>
                </thead>
                <tbody>
                 <?php $no=0; foreach($blood_list as $blood): $no++ ?>
                    <tr>
                      <td class="center"><?php echo e($no); ?></td>
                      <td class="center"><?php echo e($blood->name); ?></td>
                      <td class="center"><?php echo e($blood->category->name); ?></td>
                      <td class="center"><?php echo e($blood->alamat); ?></td>
                      <td class="center"><?php echo e($blood->keterangan); ?></td>
                      <td>
                          <a href="blood/<?php echo e($blood->id .'/edit'); ?>" class="btn btn-primary btn-sm"><i class="glyphicon glyphicon-edit"></i></a>
                          <div class="box-button">
                          <?php echo Form::open(['method'=> 'DELETE', 'action' => ['BloodController@destroy', $blood->id]]); ?>

                          <?php echo Form::submit('Delete',['class' => 'btn btn-danger btn-sm']); ?>

                          <?php echo Form::close(); ?>

                        </div>
                      </td>
                    </tr>
                  <?php endforeach ?>
                </tbody>
              </table>
              <?php echo $blood_list->render(); ?>

              <?php else: ?> if
              <p>Tidak ada data </p>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>