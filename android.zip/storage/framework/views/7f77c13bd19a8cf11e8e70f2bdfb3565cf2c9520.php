<?php $__env->startSection('content'); ?>
	<div class="content-wrapper">
    	<section class="content-header">
      <h1>
        <i class="glyphicon glyphicon-file">
        Type Blood
        </i>
      </h1>

      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Blood</a></li>
        <li class="active">Data Blood</li>
      </ol>
    </section>

    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
               <a class="btn btn-primary pull-right" href="category/create">New Blood</a>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <?php if(!empty($type_blood_list)): ?>
              <table class="table table-bordered table-hover">
                <thead>
                <tr>
                  <th class="col-sm-1">Name Blood</th>
                  <th class="col-sm-1"></th>
                </tr>
                </thead>
                <tbody>
                  <?php foreach($type_blood_list as $type_blood): ?>
                    <tr>
                      <td class="center"><?php echo e($type_blood->name); ?></td>
                       <td>
                         <a href="category/<?php echo e($category->id .'/edit'); ?>" class="btn btn-primary btn-sm"><i class="glyphicon glyphicon-edit"></i></a>
                        
                           <a href="category/<?php echo e($category->id .'/destroy'); ?>" class="btn btn-primary btn-sm"><i class="glyphicon glyphicon-erase"></i></a>
                        
                        </div>
                    </tr>
                  <?php endforeach ?>
                </tbody>
              </table>
              <?php else: ?> 
              <p>Tidak ada data category</p>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>