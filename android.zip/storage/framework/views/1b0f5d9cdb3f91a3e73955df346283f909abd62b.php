<?php $__env->startSection('content'); ?>
  
    <div class="content-wrapper">
      <section class="content-header">
        <h1>  
          Edit Blood
        </h1>

      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
          <li><a href="#">Blood</a></li>
          <li class="active">Edit Blod</li>
      </ol>
      </section>

      <section class="content">
        <div class="row">
          <div class="col-md-12">
            <div class="box box-primary"> 
              <div class="form-horizontal">
                <div class="box-body">
                <?php echo Form::model($blood, ['method' => 'PATCH', 'action' => ['BloodController@update', $blood->id]]); ?>

                <div class="form-group">
                <?php echo Form::label('blood', 'Name', ['class' => 'control-label col-sm-2']); ?>


                <div class="col-sm-5">
                <?php echo Form::text('name', null, ['class' =>'form-control']); ?>

                </div>
              </div>

              <?php if($errors->any()): ?>
              <div class="form-group <?php echo e($errors->has('category_id') ? 'has-error' : 'has-success'); ?>">
              <?php else: ?>
              <div class="form-group">
              <?php endif; ?>
                <?php echo Form::label('category_id', 'Category', ['class' => 'control-label col-sm-2']); ?>

                <?php if(count($category_list) > 0): ?>
              <div class="col-sm-5">
                <?php echo Form::select('category_id',$category_list, null, ['class' =>'form-control', 'id' => 'category_id', 'placeholder' => 'Pilih Category']); ?>

              <?php else: ?>
                <p>Tidak Ada pilihan category</p>
              <?php endif; ?>
              </div>
            </div>

            <div class="form-group">
                <?php echo Form::label('alamat', 'Alamat', ['class' => 'control-label col-sm-2']); ?>

            <div class="col-sm-5">
                <?php echo Form::text('alamat', null, ['class' =>'form-control']); ?>

            </div>
            </div>

            <div class="form-group">
                <?php echo Form::label('keterangan', 'Keterangan', ['class' => 'control-label col-sm-2']); ?>

              <div class="col-sm-5">
                    <?php echo Form::textarea('keterangan', null,  ['class' =>'form-control']); ?>

              </div>
              </div>

            <div class="box-footer">
              <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                  <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

                  <a href="edit" class="btn btn-default btn-reset">Batal</a>
                </div>
              </div>
            </div>
              <?php echo Form::close(); ?>

          </div>
        </form>
      </div>
  </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>